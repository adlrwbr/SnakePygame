from cx_Freeze import setup, Executable

executables = [Executable("Slither.py", icon="icon.ico")]

setup(
    name="Slither",
    options = {"build_exe": {"packages":["pygame"],"include_files":["apple.png", "snakehead.png", "icon.ico"]}},
    description = "Snake Arcade Game",
    author = "Adler Weber",
    executables = executables

    )
